# -*- coding: utf-8 -*-
"""
Created on Sat May  1 13:16:02 2021
Zack Rodriguez
PIC 16B Final Project Spider
@author: zackr
"""

import scrapy


class FootballSpider(scrapy.Spider):
    name = "football"
    #Class collects data from fbref.com
    def start_requests(self):
        #Starting url contains links to all pages data is scraped from
        urls = [
            'https://fbref.com/en/comps/9/3232/schedule/2019-2020-Premier-League-Scores-and-Fixtures',
            'https://fbref.com/en/comps/9/1889/schedule/2018-2019-Premier-League-Scores-and-Fixtures',
            'https://fbref.com/en/comps/9/1631/schedule/2017-2018-Premier-League-Scores-and-Fixtures'
        ]
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)
            
    def parse(self, response):
        #first parse function extracts url information from the starting page
        for link in response.css('td.left[data-stat = "match_report"] a::attr(href)'):
            #This loop appends that url info to the start url and creates a request object, which calls parse2
            full_url = response.urljoin(link.extract())
            yield scrapy.Request(full_url,self.parse2)
       
    def parse2(self, response):
        #this function is a series of css selectors that extract data from tables on each page. That data is yielded as a dictionary
        #first two vars select team names from a team stats table and extracts them as strings, which are stripped
        team_name1 = response.css("span.teamandlogo[style='padding-right: 10px']::text").extract_first().strip()
        team_name2 = response.css("span.teamandlogo[style='padding-left: 10px']::text").extract()[1].strip()
        
        #collects [home_goals,away_goals] data from top of webpage
        goals = response.css("div.score::text").extract()
        
        #collects expected goals data for each team from the top of the webpage
        xG = response.css('div.score_xg::text').extract()
        
        #This variable collects all percentage information from major stats table, only possession and passing accuracy stats will be collected as a percentage.
        pos_and_pass = response.css("td div div strong::text").extract()
        
        #shots collects shots on target and total shots information from a text line in the major stats table
        shots = response.css("tr:nth-child(7) td div div::text").re('\d+')
        
        #saves collects the number of saves and opponent shots on target for both teams. Only saves will be stored, as shots on target is collected in another field
        saves = response.css("tr:nth-child(9) td div div::text").re('\d+')
        
        #other_stats collects the entirety of the minor stats table from the webpage as a list of numbers and column/row titles. Only the numbers need to be collected to the csv
        other_stats = response.css("div[id = 'team_stats_extra'] div div:not([class])::text").extract()
        
        #The data in goals, xG, pos_and_pass, shots, saves and other_stats has a fixed, known order, allowing me to use list indexing to sort the relevant numbers
        d = {
            "home_team" : team_name1,
            "home_goals" : goals[0],
            "home_xG" : xG[0],
            "home_possession": pos_and_pass[0],
            "home_passing_accuracy" : pos_and_pass[2],
            "home_shots_on_target" : shots[0],
            "home_shots" : shots[1],
            "home_saves" : saves[0],
            "home_fouls" : other_stats[0],
            "home_corners" : other_stats[3],
            "home_crosses" : other_stats[6],
            "home_touches" : other_stats[9],
            "home_tackles" : other_stats[12],
            "home_interceptions" : other_stats[15],
            "home_aerials_won" : other_stats[18],
            "home_clearances" : other_stats[21],
            "home_offsides" : other_stats[24],
            "home_goal_kicks" : other_stats[27],
            "home_throw_ins" : other_stats[30],
            "home_long_balls" : other_stats[33],
            "away_team" : team_name2,
            "away_goals" : goals[1],
            "away_xG" : xG[1],
            "away_possession": pos_and_pass[1],
            "away_passing_accuracy" : pos_and_pass[3],
            "away_shots_on_target" : shots[2],
            "away_shots" : shots[3],
            "away_saves" : saves[2],
            "away_fouls" : other_stats[2],
            "away_corners" : other_stats[5],
            "away_crosses" : other_stats[8],
            "away_touches" : other_stats[11],
            "away_tackles" : other_stats[14],
            "away_interceptions" : other_stats[17],
            "away_aerials_won" : other_stats[20],
            "away_clearances" : other_stats[23],
            "away_offsides" : other_stats[26],
            "away_goal_kicks" : other_stats[29],
            "away_throw_ins" : other_stats[32],
            "away_long_balls" : other_stats[35]
            }
      
        yield d
        
        
        
        
        
           